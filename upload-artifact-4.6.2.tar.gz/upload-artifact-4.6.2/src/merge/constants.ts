/* eslint-disable no-unused-vars */
export enum Inputs {
  Name = 'name',
  Pattern = 'pattern',
  SeparateDirectories = 'separate-directories',
  RetentionDays = 'retention-days',
  CompressionLevel = 'compression-level',
  DeleteMerged = 'delete-merged',
  IncludeHiddenFiles = 'include-hidden-files'
}
