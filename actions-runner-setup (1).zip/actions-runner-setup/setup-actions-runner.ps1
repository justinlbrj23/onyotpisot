
# === CONFIG ===
$runnerDir = "C:\actions-runner"
$repoUrl = "https://github.com/justin-otment/onyot-AI"
$runnerToken = "BQYUZ3VNME7V6LF2WLPORB3IFKV6I"  # Replace this before running
$runnerName = "onyot-runner"
$runnerLabel = "windows"

# === Install Chocolatey (if needed) ===
Write-Host "`n--- Installing Chocolatey ---"
Set-ExecutionPolicy Bypass -Scope Process -Force
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
if (-not (Get-Command choco -ErrorAction SilentlyContinue)) {
    iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))
}

# Optional: Install required tools (Node.js, Python, Git)
choco install -y nodejs git python

# === Download GitHub Actions Runner ===
Write-Host "`n--- Setting up GitHub Actions Runner ---"
New-Item -ItemType Directory -Force -Path $runnerDir
cd $runnerDir

Invoke-WebRequest -Uri https://github.com/actions/runner/releases/latest/download/actions-runner-win-x64.zip -OutFile "runner.zip"
Expand-Archive -Path "runner.zip" -DestinationPath $runnerDir

# === Configure Runner ===
Write-Host "`n--- Configuring GitHub Actions Runner ---"
Start-Process -Wait -FilePath .\config.cmd -ArgumentList "--url $repoUrl --token $runnerToken --name $runnerName --labels $runnerLabel --unattended"

# === Install & Start as Service ===
Write-Host "`n--- Installing and Starting GitHub Actions Runner Service ---"
.\svc install
.\svc start

Write-Host "`n✅ GitHub Actions Runner is now installed and running on this machine!"
